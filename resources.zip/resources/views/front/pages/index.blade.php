@extends('front.layouts.app')

@section('title',$page->title)

@section('content')

@endsection
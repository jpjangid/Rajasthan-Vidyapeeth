@extends('front.layouts.app')

@section('content')
<h1>page not found</h1>
@endsection